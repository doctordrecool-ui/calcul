package com.example.calculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : Activity() {
    private lateinit var display: TextView
    private var current = "0"
    private var stored: Double? = null
    private var pending: String? = null
    private var startNew = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 22, 31)
        window.navigationBarColor = Color.rgb(18, 22, 31)
        window.decorView.systemUiVisibility = 0

        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(Color.rgb(18, 22, 31))
        }
        display = TextView(this).apply {
            text = current
            textSize = 48f
            setTextColor(Color.WHITE)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            maxLines = 1
            setPadding(8, 20, 8, 24)
        }
        base.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

        val rows = listOf(
            listOf("AC", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("⌫", "0", ".", "=")
        )
        val grid = GridLayout(this).apply {
            columnCount = 4
            rowCount = 5
            useDefaultMargins = false
        }
        rows.flatten().forEach { key ->
            val b = Button(this).apply {
                text = key
                textSize = 23f
                isAllCaps = false
                setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    when (key) {
                        "=", "÷", "×", "−", "+" -> Color.rgb(255, 145, 55)
                        "AC", "±", "%", "⌫" -> Color.rgb(65, 76, 94)
                        else -> Color.rgb(37, 45, 60)
                    }
                )
                setOnClickListener { press(key) }
            }
            val p = GridLayout.LayoutParams().apply {
                width = 0
                height = 76
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(5, 5, 5, 5)
            }
            grid.addView(b, p)
        }
        base.addView(grid, LinearLayout.LayoutParams(-1, -2))
        setContentView(base)
    }

    private fun refresh() { display.text = current }

    private fun press(key: String) {
        when (key) {
            "AC" -> { current = "0"; stored = null; pending = null; startNew = false }
            "⌫" -> { current = if (current.length <= 1 || (current.length == 2 && current[0] == '-')) "0" else current.dropLast(1) }
            "±" -> { if (current != "0") current = if (current.startsWith("-")) current.drop(1) else "-$current" }
            "%" -> current = format((current.toDoubleOrNull() ?: 0.0) / 100.0)
            "." -> if (startNew) { current = "0."; startNew = false } else if (!current.contains(".")) current += "."
            "+", "−", "×", "÷" -> {
                stored = current.toDoubleOrNull()
                pending = key
                startNew = true
            }
            "=" -> {
                val a = stored
                val b = current.toDoubleOrNull()
                if (a != null && b != null && pending != null) {
                    if (pending == "÷" && b == 0.0) current = "Ошибка: деление на 0"
                    else current = format(when (pending) {
                        "+" -> a + b
                        "−" -> a - b
                        "×" -> a * b
                        "÷" -> a / b
                        else -> b
                    })
                    stored = null
                    pending = null
                    startNew = true
                }
            }
            else -> if (key.length == 1 && key[0].isDigit()) {
                if (startNew || current == "0" || current.startsWith("Ошибка")) current = key
                else if (current.length < 15) current += key
                startNew = false
            }
        }
        refresh()
    }

    private fun format(value: Double): String {
        if (!value.isFinite()) return "Ошибка"
        return BigDecimal.valueOf(value).setScale(8, RoundingMode.HALF_UP)
            .stripTrailingZeros().toPlainString()
    }
}
