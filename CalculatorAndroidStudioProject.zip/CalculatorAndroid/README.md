# Калькулятор для Android

Простой калькулятор на Kotlin: сложение, вычитание, умножение, деление,
проценты, смена знака, десятичная точка и удаление последнего символа.

## Как получить APK в Android Studio

1. Распакуйте архив.
2. Откройте папку `CalculatorAndroid` в Android Studio.
3. Дождитесь завершения Gradle Sync и установки необходимых компонентов SDK.
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Минимальная версия Android: 6.0 (API 23).
